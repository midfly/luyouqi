<?php

return [
    'Name'               => '名称',
    'Discountsmaxamount' => '金额',
    'Createtime'         => '添加时间',
    'Updatetime'         => '更新时间',
    'Status'             => '状态',
    'Exchangeenddate'    => '结束时间',
    'Exchangestartdate'  => '开始时间',
    'Desc'               => '说明'
];
