<?php

return [
    'Id'         => 'ID',
    'Title'      => '标题',
    'Content'    => '描述',
    'Createtime' => '创建时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态',
    'Shop_id'    => '所属店铺',
    'Gwid'       => 'gwid',
    'Appkey'     => 'appkey'
];
