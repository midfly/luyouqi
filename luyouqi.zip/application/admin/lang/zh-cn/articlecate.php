<?php

return [
    'Name' => '名称'
];
