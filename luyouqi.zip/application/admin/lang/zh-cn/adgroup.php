<?php

return [
    'Name'        => '组名',
    'Article_ids' => 'banner分组',
    'Createtime'  => '添加时间',
    'Updatetime'  => '更新时间',
    'Status'      => '状态'
];
