<?php

return [
    'Id'          => 'ID',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Status'      => '状态',
    'Shop_id'     => '所属店铺',
    'Gwid'        => 'gwid',
    'Custom_name' => '设备名称',
    'User_ip'     => 'IP地址'
];
