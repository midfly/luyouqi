<?php

return [
    'Name'           => '名称',
    'Show_image'     => '展示图',
    'Content'        => '详情',
    'Type'           => '类型',
    'Type 0'         => '展示详情',
    'Type 1'         => '跳转url',
    'Status'         => '状态',
    'Status 0'       => '隐藏',
    'Status 1'       => '正常',
    'Articlecate_id' => '分类',
    'Createtime'     => '创建时间',
    'Updatetime'     => '更新时间',
    'Dump_uri'       => '跳转的url'
];
