<?php

return [
    'Id'          => 'ID',
    'Name'        => '标题',
    'Description' => '描述',
    'Createtime'  => '创建时间',
    'Updatetime'  => '更新时间',
    'Status'      => '状态'
];
