<?php

return [
    'Name'       => '名称',
    'Price'      => '单价',
    'Amount'     => '价格',
    'Haoping'    => '好评率',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态',
    'Image'      => '图片',
    'Url'        => '跳转url'
];
