<?php

return [
    'Id'               => 'ID',
    'Name'             => '标题',
    'Content'          => '描述',
    'Createtime'       => '创建时间',
    'Updatetime'       => '更新时间',
    'Status'           => '状态',
    'Shopcategory_ids' => '店铺分类'
];
